function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
 let barco;
let camaroes = [];
let multa = 0;
let estadoJogo = "jogando"; // "jogando", "perseguicao", "preso"
let policia;
let tempoPerseguicao = 0;
let bonecoFalando = false;

function setup() {
  createCanvas(800, 600);
  barco = new Barco();
  policia = new Policia();
}

function draw() {
  background(135, 206, 235); // cor de água
  textSize(24);
  fill(0);
  text("Multa: R$ " + multa.toFixed(2), 10, 30);

  if (estadoJogo === "jogando") {
    barco.mover();
    barco.show();

    if (frameCount % 60 === 0) {
      camaroes.push(new Camarao());
    }

    for (let i = camaroes.length - 1; i >= 0; i--) {
      camaroes[i].show();
      if (barco.intersects(camaroes[i])) {
        multa += 110;
        camaroes.splice(i, 1);

        if (multa >= 10000) {
          estadoJogo = "perseguicao";
          tempoPerseguicao = frameCount;
        }
      }
    }
  } else if (estadoJogo === "perseguicao") {
    barco.mover();
    barco.show();
    policia.seguir(barco.x, barco.y);
    policia.show();

    textSize(32);
    fill(255, 0, 0);
    text("🚨 A polícia está te perseguindo!", width / 2 - 200, 50);

    if (frameCount - tempoPerseguicao > 300) {
      estadoJogo = "preso";
    }
  } else if (estadoJogo === "preso") {
    barco.show();
    policia.show();
    textSize(32);
    fill(255, 0, 0);
    text("🚔 Você foi preso pela pesca ilegal!", width / 2 - 250, height / 2 - 50);
    bonecoFalando = true;
  }

  // Mensagem final do bonequinho
  if (bonecoFalando) {
    textSize(24);
    fill(0);
    text("👤 Policial: Você estava pescando ilegalmentes, pois esta em epoca de reproduçã dos camarões ", 50, height - 50)
  }
}

// Classe do barco
class Barco {
  constructor() {
    this.x = width / 2;
    this.y = height - 80;
    this.velocidade = 5;
  }

  mover() {
    if (keyIsDown(LEFT_ARROW) && this.x > 0) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW) && this.x < width - 40) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW) && this.y > 0) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW) && this.y < height - 40) {
      this.y += this.velocidade;
    }
  }

  show() {
    textSize(48);
    text("🚤", this.x, this.y);
  }

  intersects(cam) {
    let d = dist(this.x, this.y, cam.x, cam.y);
    return d < 40;
  }
}

// Classe dos camarões
class Camarao {
  constructor() {
    this.x = random(50, width - 50);
    this.y = random(50, height - 150);
  }

  show() {
    textSize(32);
    text("🦐", this.x, this.y);
  }
}

// Classe da polícia
class Policia {
  constructor() {
    this.x = width / 2;
    this.y = 50;
  }

  seguir(alvoX, alvoY) {
    let dirX = alvoX - this.x;
    let dirY = alvoY - this.y;
    this.x += dirX * 0.02;
    this.y += dirY * 0.02;
  }

  show() {
    textSize(48);
    text("🚔", this.x, this.y);
  }
}
